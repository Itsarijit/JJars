package com.runner;
import cucumber.api.CucumberOptions;
import cucumber.api.junit.Cucumber;

import org.junit.runner.RunWith;

@RunWith(Cucumber.class)
@CucumberOptions(
		dryRun = false,
		strict = true,
		features = {"src/"},
		glue = {"com.runner"},
		monochrome = true,
		format = {
				"pretty",
				"html:target/cucumber",
				"json:target_json/cucumber.json",
				"junit:taget_junit/cucumber.xml"
				}
		)
public class RunCukesTest {

}
