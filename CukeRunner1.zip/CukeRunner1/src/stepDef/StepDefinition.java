package stepDef;
import cucumber.api.PendingException;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.support.ui.ExpectedCondition;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertTrue;
import static org.junit.Assert.assertFalse;
public class StepDefinition {

	WebDriver driver = null;
	
	@Given("^the page is open \"(.*?)\"$")
	public void the_page_is_open(String page) throws Throwable {
		driver = new FirefoxDriver();
		driver.get(page);
	    // Write code here that turns the phrase above into concrete actions
	    
	}

	@When("^I search for \"(.*?)\"$")
	public void i_search_for(String search) throws Throwable {
		WebElement element = driver.findElement(By.name("q"));
		element.sendKeys(search);
		element.submit();
	    // Write code here that turns the phrase above into concrete actions
	    
	}

	@Then("^a browser title should contains \"(.*?)\"$")
	public void a_browser_title_should_contains(String text1) throws Throwable {
		  System.out.println( "Page title is: " + driver.getTitle());
		//assertTrue(driver.getTitle().contains(text));
	    // Write code here that turns the phrase above into concrete actions
	    
	}	
	
	@Given("^the page already open \"(.*?)\"$")
	public void the_page_already_open(String page) throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
		driver = new FirefoxDriver();
		driver.get(page);
	}
	@When("^I select start station \"(.*?)\" End Station \"(.*?)\" and Submit$")
	public void i_select_start_station_End_Station_and_Submit(String Station1, String Station2) throws Throwable {
		new Select(driver.findElement(By.name("lccp_src_stncode"))).selectByVisibleText(Station1);
		new Select(driver.findElement(By.name("lccp_dstn_stncode"))).selectByVisibleText(Station2);
		driver.findElement(By.name("submit2")).click();
		
	}

	
}
